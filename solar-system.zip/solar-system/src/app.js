// Set up the scene, camera, and renderer with anti-aliasing enabled
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Set the background to black for space
renderer.setClearColor(0x000000); // Pure black background for space

// Function to add glimmering stars
function addStars() {
  const starGeometry = new THREE.SphereGeometry(0.1, 24, 24);
  const starMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });

  for (let i = 0; i < 300; i++) { // Create 300 stars
    const star = new THREE.Mesh(starGeometry, starMaterial);

    // Position stars randomly around the scene
    const [x, y, z] = Array(3).fill().map(() => THREE.MathUtils.randFloatSpread(200)); // Random spread
    star.position.set(x, y, z);

    scene.add(star);
  }
}

// Add stars to the scene
addStars();

// Create the sun (cartoony and bright yellow) with smoother geometry
const sunGeometry = new THREE.SphereGeometry(4, 64, 64); // More segments for smoother appearance
const sunMaterial = new THREE.MeshPhongMaterial({ color: 0xffe600, shininess: 30 }); // Shininess for polished look
const sun = new THREE.Mesh(sunGeometry, sunMaterial);
scene.add(sun);

// Add a glow effect around the sun
const sunGlowGeometry = new THREE.SphereGeometry(5, 32, 32); // Slightly larger than the sun
const sunGlowMaterial = new THREE.MeshBasicMaterial({
  color: 0xffff99,
  transparent: true,
  opacity: 0.5, // Make it glow with some transparency
});
const sunGlow = new THREE.Mesh(sunGlowGeometry, sunGlowMaterial);
scene.add(sunGlow);

// Create Earth (cartoony blue) with smoother geometry
const earthGeometry = new THREE.SphereGeometry(1.2, 64, 64); // More segments for smoothness
const earthMaterial = new THREE.MeshPhongMaterial({ color: 0x3498db, shininess: 10 }); // Phong material for polished look
const earth = new THREE.Mesh(earthGeometry, earthMaterial);

// Set Earth's initial position
const earthOrbitRadius = 10;
earth.position.x = earthOrbitRadius;
scene.add(earth);

// Create Mars (cartoony red) with smoother geometry
const marsGeometry = new THREE.SphereGeometry(1, 64, 64);
const marsMaterial = new THREE.MeshPhongMaterial({ color: 0xe74c3c, shininess: 10 });
const mars = new THREE.Mesh(marsGeometry, marsMaterial);

// Set Mars' initial position
const marsOrbitRadius = 16;
mars.position.x = marsOrbitRadius;
scene.add(mars);

// Create Jupiter (cartoony orange) with smoother geometry
const jupiterGeometry = new THREE.SphereGeometry(2.5, 64, 64); // More segments for smoothness
const jupiterMaterial = new THREE.MeshPhongMaterial({ color: 0xf39c12, shininess: 20 });
const jupiter = new THREE.Mesh(jupiterGeometry, jupiterMaterial);

// Set Jupiter's initial position
const jupiterOrbitRadius = 24;
jupiter.position.x = jupiterOrbitRadius;
scene.add(jupiter);

// Add soft lighting to enhance cartoonish feel
const light = new THREE.PointLight(0xffffff, 1.5, 100); // Soft white light
light.position.set(0, 0, 0); // Light from the sun's position
scene.add(light);

// Add ambient light for a softer overall light
const ambientLight = new THREE.AmbientLight(0x404040, 0.5); // Softer ambient light
scene.add(ambientLight);

// Set the camera to a bird's-eye view
camera.position.set(0, 40, 0); // Move the camera up, above the solar system
camera.lookAt(0, 0, 0); // Point the camera to the center (the sun)

// Animation loop to simulate the orbits
function animate() {
  requestAnimationFrame(animate);

  const time = Date.now() * 0.001;

  // Earth orbit
  earth.position.x = Math.cos(time) * earthOrbitRadius;
  earth.position.z = Math.sin(time) * earthOrbitRadius;

  // Mars orbit
  mars.position.x = Math.cos(time * 0.8) * marsOrbitRadius; // Slower than Earth
  mars.position.z = Math.sin(time * 0.8) * marsOrbitRadius;

  // Jupiter orbit
  jupiter.position.x = Math.cos(time * 0.4) * jupiterOrbitRadius; // Slower than Mars
  jupiter.position.z = Math.sin(time * 0.4) * jupiterOrbitRadius;

  // Slight twinkling effect for the stars (randomize their opacity)
  scene.children.forEach(star => {
    if (star.material && star.material.opacity !== undefined) {
      star.material.opacity = 0.8 + Math.random() * 0.2; // Slight variation for twinkling effect
    }
  });

  renderer.render(scene, camera);
}

animate();

// Handle window resizing
window.addEventListener('resize', () => {
  renderer.setSize(window.innerWidth, window.innerHeight);
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
});
